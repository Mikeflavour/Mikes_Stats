package net.minecraft.world.level.storage.loot.providers.number;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.commands.arguments.NbtPathArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NumericTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.storage.loot.LootContext;

public record StorageValue(Identifier storage, NbtPathArgument.NbtPath path) implements NumberProvider {
	public static final MapCodec<StorageValue> MAP_CODEC = RecordCodecBuilder.mapCodec(
		i -> i.group(
				Identifier.CODEC.fieldOf("storage").forGetter(StorageValue::storage), NbtPathArgument.NbtPath.CODEC.fieldOf("path").forGetter(StorageValue::path)
			)
			.apply(i, StorageValue::new)
	);

	@Override
	public MapCodec<StorageValue> codec() {
		return MAP_CODEC;
	}

	private Number getNumericTag(final LootContext context, final Number _default) {
		CompoundTag value = context.getLevel().getServer().getCommandStorage().get(this.storage);

		try {
			List<Tag> selectedTags = this.path.get(value);
			if (selectedTags.size() == 1 && selectedTags.getFirst() instanceof NumericTag result) {
				return result.box();
			}
		} catch (CommandSyntaxException var7) {
		}

		return _default;
	}

	@Override
	public float getFloat(final LootContext context) {
		return this.getNumericTag(context, 0.0F).floatValue();
	}

	@Override
	public int getInt(final LootContext context) {
		return this.getNumericTag(context, 0).intValue();
	}
}
